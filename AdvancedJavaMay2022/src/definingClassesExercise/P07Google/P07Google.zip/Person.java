package definingClassesExercise.P07Google;

import java.util.List;

public class Person {
    private String name;
    private Company company;
    private List<Pokemon> pokemon;
    private List<Parent> parent;
    private List<Children> children;
    private Car car;


    public Person(String name, List<Pokemon> pokemon, List<Parent> parent, List<Children> children) {
        this.name = name;
        this.pokemon = pokemon;
        this.parent = parent;
        this.children = children;
    }

    public void setCompany(Company company) {
        this.company = company;
    }
    public void setCar(Car car) {
        this.car = car;
    }

    public void addPokemon(Pokemon pokemon) {
        this.pokemon.add(pokemon);
    }
    public void addParent(Parent parent) {
        this.parent.add(parent);
    }
    public void addChild(Children child) {
        this.children.add(child);
    }

    public void printFormat() {
        System.out.println(name);
        System.out.println("Company:");
        if(company != null) {
            System.out.println(company.format());
        }
        System.out.println("Car:");
        if(car != null) {
            System.out.println(car.format());
        }
        System.out.println("Pokemon:");
        if(!pokemon.isEmpty()) {
            pokemon.forEach(e -> System.out.printf("%s%n", e.format()));
        }
        System.out.println("Parents:");
        if(!parent.isEmpty()) {
            parent.forEach(e -> System.out.printf("%s%n", e.format()));
        }
        System.out.println("Children:");
        if(!children.isEmpty()) {
            children.forEach(e -> System.out.printf("%s%n", e.format()));
        }
    }

}
